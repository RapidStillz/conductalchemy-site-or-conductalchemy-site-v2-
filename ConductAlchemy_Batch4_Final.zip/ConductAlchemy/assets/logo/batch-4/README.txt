Conduct Alchemy — Batch 4 (A+B+C)
A) web-icons: clean silhouette for UI/favicons
B) editorial: textured motif for hero/editorial use
C) social: square + circle avatars, PNG + JPG

All assets derived from master lockup image provided by user.
