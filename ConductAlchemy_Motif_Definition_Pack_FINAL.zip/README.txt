Conduct Alchemy – Motif Definition Pack (FINAL)

These files are the authoritative master assets as supplied and approved.
No reinterpretation or regeneration has been performed.

01_Masters:
- Primary textured motif and logo masters

03_Reference:
- Draftsman / construction reference (non-identity)

Next steps:
- Derivatives (transparent overlays, white negatives, print exports)
- Vectorisation from clean silhouette (guided separately)
