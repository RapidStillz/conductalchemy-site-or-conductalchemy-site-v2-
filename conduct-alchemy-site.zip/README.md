# Conduct Alchemy — Static Site (Cloudflare Pages)

Lightweight static site intended for deployment on Cloudflare Pages.

## Deploy (Cloudflare Pages)
- Framework preset: **None**
- Build command: (leave empty)
- Output directory: `/`

## Update “Ah Mm”
Replace the placeholder video:
- `assets/video/ah-mm-60s.mp4`
- `assets/video/ah-mm-15s.mp4`

Then update `/work/ah-mm/index.html` video sources.

