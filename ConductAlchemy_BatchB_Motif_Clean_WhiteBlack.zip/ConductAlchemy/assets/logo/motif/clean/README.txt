Conduct Alchemy — Batch B (Clean Motif)
Files included:
- ca-motif-clean-black_[size].png (transparent background)
- ca-motif-clean-white_[size].png (transparent background)

Recommended use:
- 2048 for print/video mockups
- 1024 for web hero / high-DPI
- 512 for UI elements
- 192/180/48/32 for favicons/app icons

All PNGs are RGBA with transparency.
